import serial
import socketio
import math


PROTOPIE_SERVER = "http://localhost:9981"
PORT = "/dev/cu.usbmodem1101"
BAUDRATE = 115200


################## STATE ########################


STEP_SIZE = 30 # how much turn is required before we register a step for direction

# wrap-direction lock system
wrap_block_active = False
wrap_block_direction = None
last_angle = None
previous_step = None

# state from ProtoPie
screen = "Select Drink"
active_setting = "Strength"

################## SOCKET ########################

sio = socketio.Client()

@sio.event
def connect():
    print("[SOCKETIO] Connected")
    print("[PYTHON -> PROTOPIE] Sending bridge handshake")
    sio.emit('ppBridgeApp', {'name': 'PythonBridge'})
    print("[PYTHON -> PROTOPIE] Sending connected status")
    sio.emit('ppMessage', {'messageId': 'connected', 'value': 'Connected from Python'})

@sio.event
def disconnect():
    print("[SOCKETIO] Disconnected")

@sio.on('ppMessage')
def on_pp_message(data):
    global screen, active_setting

    message_id = data.get("messageId")
    value = data.get("value")

    print(f"[PROTOPIE -> PYTHON] {message_id}: {value}")

    ######## [CUSTOM] Receiving Messages ########
    if message_id == "SCENE CHANGE":
        screen = value

    elif message_id == "SETTING CHANGE":
        active_setting = value 

######## [CUSTOM] Helper Function: turn angle to direction ########

def angle_to_direction(angle):
    global previous_step, last_angle
    global wrap_block_active, wrap_block_direction

    if angle is None:
        return None
    step = int((angle + STEP_SIZE / 2) // STEP_SIZE)

    if previous_step is None:
        previous_step = step
        last_angle = angle
        return None

    if abs(step - previous_step) > 1:
        previous_step = step
        last_angle = angle
        return None

    if step > previous_step:
        direction = "RIGHT"
    elif step < previous_step:
        direction = "LEFT"
    else:
        last_angle = angle
        return None

    previous_step = step
    last_angle = angle

    print(f"Step: {step}, Direction: {direction}")
    return direction

################## MAIN LOOP ########################

try:
    ser = serial.Serial(PORT, BAUDRATE, timeout=1)
    print(f"Connected to {PORT}")

    sio.connect(PROTOPIE_SERVER)
    print("Connected to ProtoPie")

    while True:

        if ser.in_waiting > 0:
            line = ser.readline().decode("utf-8", errors="ignore").strip()
            print(f"[ARDUINO -> PYTHON] Received raw value: {line}")
            try:
                raw_angle = float(line)
                if math.isnan(raw_angle):
                    continue
            except ValueError:
                continue

            angle = raw_angle

            ################ [CUSTOM] Select Drink Scene ################
            if screen == "Select Drink":
                direction = angle_to_direction(angle)
                if direction:
                    print(f"[PYTHON -> PROTOPIE] Sent DIRECTION CHANGE: {direction}")
                    sio.emit('ppMessage', {
                        'messageId': 'DIRECTION CHANGE', 
                        'value': direction
                    })

            ################ [CUSTOM] Customize Drink Scene ################
            if screen == "Customize Drink":

                ######## Setting - Strength ########
                if active_setting == "Strength":
                    direction = angle_to_direction(angle)
                    if direction:
                        print(f"[PYTHON -> PROTOPIE] Sent DIRECTION CHANGE: {direction}")
                        sio.emit('ppMessage', {
                            'messageId': 'DIRECTION CHANGE',
                            'value': direction
                        })

                ######## Setting - Strength / Temperature / Volume ########
                if active_setting == "Strength" or active_setting == "Temperature" or active_setting == "Volume":
                    print(f"[PYTHON -> PROTOPIE] Sent ANGLE CHANGE: {angle}")
                    sio.emit('ppMessage', {
                        'messageId': 'ANGLE CHANGE',
                        'value': angle
                    })

except KeyboardInterrupt:
    print("\nExiting...")

finally:
    if 'ser' in locals() and ser.is_open:
        ser.close()
        print("Serial closed")