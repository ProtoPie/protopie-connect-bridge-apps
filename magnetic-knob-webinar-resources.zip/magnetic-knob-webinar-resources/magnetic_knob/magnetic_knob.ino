#include <Wire.h>
#include "MT6701.h"
#define ALPHA 0.2 // Smoothing factor (Low-Pass Filter weight)

MT6701 encoder;

float current_angle = 0; 
bool initialized = false;


// Stablize reading by ignoring micro-movements smaller than the deadzone
float getDeadzone(float angle) {
    // If the knob is resting between 0 and 280, deadzone is 4
    if (angle <= 280) return 4.0;
    // If the knob is resting between 281 and 360 (near the end of its rotation), deadzone widens to 6
    return 6.0;
}

// Smooth and wrap angle
float smoothAngle(float newAngle) {
    if (!initialized) {
        current_angle = newAngle;
        initialized = true;
    }

    // Get the shortest circulur difference
    float diff = newAngle - current_angle;
    if (diff > 180) diff -= 360; // 359 - 0 = 359 => 359-360 = -1
    if (diff < -180) diff += 360; // 0 - 359 = -359 => -359 + 360 = 1
    // Dynamic deadzone
    float DEADZONE = getDeadzone(current_angle);

    // Update angle if the difference is greater than the deadzone
    if (abs(diff) >= DEADZONE) {
        current_angle += ALPHA * diff;
    }

    // Wrap angle
    if (current_angle < 0) current_angle += 360;
    if (current_angle >= 360) current_angle -= 360;

    return round(current_angle);
}


// ================= SETUP =================
void setup() {
    Serial.begin(115200); // Open the USB communication pipeline
    Wire.begin(); // Start the I2C communication network
    encoder.initializeI2C(); // Wake up the physical MT6701 sensor

    Serial.println("Encoder smoothing started...");
}

// ================= LOOP =================
void loop() {
    float raw_angle = encoder.angleRead(); // Read the raw angle
    if (isnan(raw_angle)) return; // Handle errors
    float filtered_angle = smoothAngle(raw_angle); // Process the raw angle

    Serial.println(filtered_angle); 

    delay(10);
}